
# Pointage des heures
Ouvrez index.html, connectez-vous, tout est sauvegardé sur Firebase.
Pour sauvegarder localement, zippez votre dossier.
